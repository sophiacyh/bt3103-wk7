<template>
  <div id="app">
    <h2>Menu</h2>
    <ul>
      <li v-for="(itm, index) in itemsSelected" :key="index">
        {{itm[0]}} x {{itm[1]}}
      </li>
    </ul>
    <button v-on:click = "Clicked(); findTotal(); sendOrder()">Calculate Total</button>
    <p v-show = "this.clicked">
      Subtotal: ${{total}}<br>
      Grand Total: ${{(total*1.07).toFixed(2)}}
    </p>
  </div>
</template>

<script>
import database from "../firebase.js";
export default {
  data() {
    return {
      total: 0,
      clicked: false
    }
  },
  methods: {
    Clicked: function() {
      this.clicked = true;
    },
    findTotal: function() {
      var added = 0;
      for (let i = 0; i < this.itemsSelected.length; i++) {
        var itemCount = this.itemsSelected[i][1];
        var itemPrice = this.itemsSelected[i][2];
        added+=itemPrice*itemCount;
      }
      this.total = added;
    },
    sendOrder: function() {
      var order = {};
      for (let i = 0; i < this.itemsSelected.length; i++) {
        var itemName = this.itemsSelected[i][0];
        var itemCount = this.itemsSelected[i][1];
        //var itemPrice = this.itemsSelected[i][2];
        order[itemName]=itemCount;
      }
      database.collection('orders').add(order).then(() => {location.reload()});
    }
  },
  props: {
    itemsSelected: {
      type: Array
    }
  }
}
</script>

<style scoped>
div {
  font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
}
ul {
  margin: 15px;
}
li {
  font-size: 15px;
}
button {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  text-align: center;
  background-color: #ffb4e0fd;
  border-radius: 25%;
  padding: 10px 15px;
  font-size: 15px;
}
</style>