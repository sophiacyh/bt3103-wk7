<template>
  <div id="app">
    <ul id="items">
      <li v-for = "(value, key, index) in this.datapacket" :key = "index">
        {{key}} : {{value}}
        <br>
        <input v-bind:id = "index" placeholder="0" type="number" min="0" max="10">
        <br>
      </li>
    </ul>
    <button v-on:click = "updateOrder">Update Order</button>
  </div>
</template>

<script>
import database from "../firebase.js";
export default {
  name: 'Modify',
  data() {
    return {
      datapacket: []
    }
  },
  props: {
    id: {
      type: String,
    }
  },
  methods: {
    fetchItems: function() {
      database.collection('orders').doc(this.id).get().then(snapshot => {
        this.datapacket = snapshot.data();
      });
    },
    updateOrder: function() {
      var copy = {};
      for (let item in this.datapacket) {
        copy[item] = item.value;
      }
      var i = 0;
      for (let itm in copy) {
        var c = document.getElementById(i).value;
        if (c == "") {
          copy[itm] = 0;
        } else {
          copy[itm] = c;
        }
        i++;
      }
      database.collection('orders').doc(this.id).update(copy).then(this.$router.push("orders"));
    }
  },
  created:function() {
    this.fetchItems();
  }
}

</script>

<style scoped>
#items {
  list-style-type: none;
}
button {
  height: 30px;
  background-color: #f7cac9;
  border-radius: 10px;
  border-width: 1px;
  margin-left: 35px;
}
</style>