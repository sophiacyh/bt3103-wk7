<template>
  <div id="app">
    <ul id = "lstOfOrders">
      <li id = "order" v-for = "ord in orders" :key = "ord.index"> 
        <ul id="items"> 
          <li v-for = "(value, key) in ord[1]" :key = value.index>
            {{key}} : {{value}}
          </li>
        </ul>
        <button v-bind:id = "ord[0]" v-on:click = "deleteItem($event)">Delete</button>
        <button v-bind:id = "ord[0]" v-on:click = "route($event)">Modify</button>
      </li>
    </ul>  
  </div>
</template>

<script>
import database from "../firebase.js";

export default {
  data() {
    return {
      orders: []
    }
  },
  methods: {
    fetchItems: function() {
      database.collection('orders').get().then(snapshot => { 
        snapshot.docs.forEach(doc => { 
          this.orders.push([doc.id, doc.data()]);
        });
      });
    },

    deleteItem: function(event) {
      let doc_id = event.target.getAttribute("id");
      database.collection('orders').doc(doc_id).delete().then(()=>location.reload());
    },

    route: function(event) {
      let doc_id = event.target.getAttribute("id");
      this.$router.push({name: 'Modify',  params: { id: doc_id }})
    }
  },
  created() {
    this.fetchItems()
  },
}
</script>

<style scoped>
#lstOfOrders {
  display: flex;
  flex-wrap: wrap;
  list-style-type: none;
  padding: 0;
}
#order {
  flex-grow: 1;
  flex-basis: 300px;
  text-align: center;
  padding: 10px;
  border: 1px solid #222;
  margin: 10px;
}

#items {
  float:left;
  list-style-type: none;
}

button {
  width: 65px;
  height: 30px;
  background-color: #f7cac9;
  border-radius: 10px;
  border-width: 1px;
}
</style>
