<template>
  <div>
    <button v-on:click="minus">-</button>
    <span>{{counter}}</span>
    <button v-on:click="add">+</button>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        counter: 0
      }
    },
    props: {
      item: {
        type: Object
      }
    },
    methods: {
      add: function() {
        if (this.counter == 10) {
          alert("You cannot buy more than 10 items.");
        }
        else {
          this.counter++;
        }
        this.$emit('counter', this.item, this.counter)
      },
      minus: function() {
        if (this.counter!=0) {
          this.counter--;
        }
        this.$emit('counter', this.item, this.counter)
      }
    }
  } 
</script>

<style scoped>
  button {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
    text-align: center;
    background-color: #ffb4e0fd;
    border-radius: 20%;
    padding: 10px 20px;
    margin: 20px;
    font-size: 25px
  }
  span {
    font-size: 20px;
  }
</style>