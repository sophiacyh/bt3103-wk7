import firebase from "firebase"

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCogqDVSyMknWUPRbzAem8KGR5Wf7GXd6Y",
  authDomain: "bt3103-wk6-scyh.firebaseapp.com",
  projectId: "bt3103-wk6-scyh",
  storageBucket: "bt3103-wk6-scyh.appspot.com",
  messagingSenderId: "382122606450",
  appId: "1:382122606450:web:cc5fd41140b47ce59d67eb",
  measurementId: "G-KRTY4N12DX"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

var database = firebase.firestore();
export default database;