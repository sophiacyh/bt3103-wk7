import Home from './components/PageContent.vue'
import Orders from './components/Orders.vue'
import Modify from './components/Modify.vue'

export default [
  { path: '/', component: Home },
  { path: '/orders', component: Orders },
  { path: '/modify', name: 'Modify', component: Modify, props: true }
]